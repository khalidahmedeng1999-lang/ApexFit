# ApexFit EG - Android Project

A modern Android workout logger and hybrid athlete fitness application built with Kotlin, Jetpack Compose, Material Design 3, and Room Database.

## Features
- **14-Day & 7-Day Custom Workout Splits**: Flexible split management without enforced activity names.
- **Cardio & Movement Categorization**: Compound, Isolation, Core, Power, Conditioning, Zone 2, and Rest tracking.
- **Coaching Notes & Cues**: Track Rep Ranges, RIR (Reps in Reserve), and detailed notes per exercise.
- **ApexFit Hybrid Preset**: Built-in 14-day split ready to activate with one tap.
- **Room Local Database**: Fully offline-first local state persistence.

## How to Build in Android Studio
1. Unzip this project directory on your computer.
2. Open **Android Studio** (2023.1 or newer recommended).
3. Select **Open** and choose the unzipped folder.
4. Allow Gradle to sync dependencies automatically.
5. Click **Run** ▶️ or build the APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## How to Build via Command Line
```bash
./gradlew assembleDebug
```
The compiled APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
